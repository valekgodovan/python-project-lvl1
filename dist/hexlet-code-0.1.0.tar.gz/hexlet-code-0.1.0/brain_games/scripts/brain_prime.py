#!/usr/bin/env python
"""Main program."""
from brain_games.games.prime import prime


def main():
    """Run great common divisor logic."""
    prime()


if __name__ == '__main__':
    main()
