#!/usr/bin/env python
"""Main program."""
from brain_games.even import welcome_user


def main():
    """Main logic."""
    welcome_user()


if __name__ == '__main__':
    main()
