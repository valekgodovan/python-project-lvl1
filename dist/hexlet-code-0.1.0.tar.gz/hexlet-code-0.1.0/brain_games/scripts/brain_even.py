#!/usr/bin/env python
"""Main program."""
from games.even import even


def main():
    """Run even logic."""
    even()


if __name__ == '__main__':
    main()
