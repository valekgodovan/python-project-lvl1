#!/usr/bin/env python
"""Main program."""
from brain_games.games.even import even


def main():
    """Run even logic."""
    even()


if __name__ == '__main__':
    main()
