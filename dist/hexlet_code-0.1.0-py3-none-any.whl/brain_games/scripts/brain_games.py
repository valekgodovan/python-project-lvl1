#!/usr/bin/env python

from brain_games.cli import main

if __name__ == '__main__':
    main()